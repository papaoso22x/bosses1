# NebulaBosses 1.0.0

Plugin de bosses para Paper 1.21.11 + MythicMobs. Soporta:

- **Arena fija (FIXED)** o **instancias (INSTANCE)**: copia del mundo plantilla por grupo, se borra al terminar.
- **Inicio por grupo** (`/boss join`) y **por horario** (evento con avisos globales).
- Escalado de nivel por jugadores, muertes limitadas, ranking de daño, recompensas por comandos, cooldowns.

## Compilar
Opción rápida sin instalar nada: sube esta carpeta a un repositorio de GitHub; el workflow
`.github/workflows/build.yml` compila solo y deja el .jar en la pestaña Actions -> Artifacts.

Opción local:
Necesitas JDK 21 y Maven:

    mvn package

El jar queda en `target/NebulaBosses.jar` -> cópialo a `plugins/`.
Si Maven no encuentra `Mythic-Dist:5.13.0`, cambia la versión en `pom.xml` por una más reciente.

## Puesta en marcha (ejemplo con Herobrine)
1. Instancias: deja el mundo plantilla como carpeta en la raíz del servidor (ej. `bosses_herobrine`)
   con los gamerules ya puestos (keepInventory, doMobSpawning, etc.). El plugin solo lo copia.
2. Edita `plugins/NebulaBosses/bosses.yml` (o `/boss admin create <id> <INSTANCE|FIXED>`).
3. Fija ubicaciones parado en cada punto:
   `/boss admin setlobby herobrine` (sala de espera, mundo real)
   `/boss admin setarena herobrine` (donde aparecen los jugadores; en INSTANCE hazlo en el mundo plantilla)
   `/boss admin setboss herobrine` (donde aparece el boss)
   `/boss admin setexit herobrine` (a dónde salen al terminar)
4. `/boss admin reload` y prueba con `/boss join herobrine`.
   Evento de prueba sin esperar horario: `/boss admin event herobrine`.

## Comandos
Jugadores: `/boss list | join <id> | leave | start | lock | invite <jugador> | accept | info`
Admin (`nebulabosses.admin`): `/boss admin reload | create | setlobby | setarena | setboss | setexit | event | stop | resetcooldown`
Permiso `nebulabosses.bypass`: ignora cooldowns y comandos bloqueados.

## Notas sobre tus archivos de Herobrine
- `Drops` del mob: si dejas el dinero/mobcoins en MythicMobs **y** en `rewards`, se pagan dos veces. Usa uno.
- `Herobrine_Escalar` fija el nivel a los 5 s según jugadores a 40 bloques; el plugin ya fija el nivel
  al aparecer (`scale-level`). Puedes dejar ambos o quitar uno.
- Las skills de tormenta/hora afectan al mundo donde está el boss: en INSTANCE solo a la copia.

## Pendiente / por probar
Está escrito para Paper 1.21.11 y la API de MythicMobs 5.x, pero **no se pudo compilar ni probar en el
entorno donde se generó**. Si Maven marca un error de compilación, pásalo tal cual para corregirlo.
