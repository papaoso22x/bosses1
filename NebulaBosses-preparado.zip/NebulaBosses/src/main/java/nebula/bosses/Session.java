package nebula.bosses;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Una pelea (sala de espera -> cuenta atrás -> intro -> pelea -> fin) contra un boss. */
public final class Session {
    public enum State { WAITING, COUNTDOWN, INTRO, FIGHTING, ENDED }

    public enum Kind { MANUAL, EVENT }

    private final NebulaBosses plugin;
    public final BossDefinition def;
    public final int number;
    public Kind kind;
    public State state = State.WAITING;
    public UUID leader;
    public boolean locked;
    public final Set<UUID> players = new LinkedHashSet<>();
    private final Map<UUID, String> names = new HashMap<>();
    private final Map<UUID, Double> damage = new HashMap<>();
    private final Map<UUID, Integer> deaths = new HashMap<>();
    public World arena;
    private boolean instanceWorld;
    private boolean prepStarted;
    private boolean prepFailed;
    private UUID bossUuid;
    private int counter;
    private int waited;
    private int missingBoss;
    private int maxPlayers;
    private BukkitTask task;

    public Session(NebulaBosses plugin, BossDefinition def, Kind kind, int number) {
        this.plugin = plugin;
        this.def = def;
        this.kind = kind;
        this.number = number;
        this.maxPlayers = kind == Kind.EVENT ? def.eventMax : def.max;
    }

    public int maxPlayers() {
        return maxPlayers;
    }

    public int counter() {
        return counter;
    }

    public void start() {
        if (kind == Kind.EVENT) {
            state = State.COUNTDOWN;
            counter = def.joinWindow;
            prepare();
        }
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    /** Una sala manual en espera pasa a ser el evento programado. */
    public void convertToEvent() {
        kind = Kind.EVENT;
        maxPlayers = def.eventMax;
        locked = false;
        state = State.COUNTDOWN;
        counter = def.joinWindow;
        prepare();
    }

    // ------------------------------------------------------------------ preparación de la arena

    private void prepare() {
        if (prepStarted) return;
        prepStarted = true;
        if (def.type == BossDefinition.Type.FIXED) {
            World w = def.arenaSpawn == null ? null : Bukkit.getWorld(def.arenaSpawn.world());
            if (w == null) prepFailed = true;
            else arena = w;
            return;
        }
        instanceWorld = true;
        String name = InstanceWorlds.PREFIX + def.id + "_" + number;
        plugin.instances().create(def.template, name, w -> {
            if (state == State.ENDED) {
                plugin.instances().destroy(w);
                return;
            }
            arena = w;
        }, () -> prepFailed = true);
    }

    // ------------------------------------------------------------------ jugadores

    public void broadcast(String key, Object... kv) {
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) plugin.lang().send(p, key, kv);
        }
    }

    private void actionbar(String key, Object... kv) {
        Component c = plugin.lang().comp(key, kv);
        for (UUID id : players) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.sendActionBar(c);
        }
    }

    public void join(Player p) {
        UUID id = p.getUniqueId();
        players.add(id);
        names.put(id, p.getName());
        if (leader == null) leader = id;
        plugin.sessions().register(id, this);
        if (def.lobby != null) {
            Location lobby = def.lobby.resolve();
            if (lobby != null) p.teleport(lobby);
        }
        plugin.lang().send(p, "joined", "boss", def.display, "n", players.size(), "max", maxPlayers, "min", def.min);
        for (UUID other : players) {
            if (other.equals(id)) continue;
            Player o = Bukkit.getPlayer(other);
            if (o != null) plugin.lang().send(o, "player-joined", "player", p.getName(), "n", players.size(), "max", maxPlayers);
        }
    }

    public void leave(Player p, boolean teleportOut) {
        UUID id = p.getUniqueId();
        if (!players.remove(id)) return;
        plugin.sessions().unregister(id);
        if (id.equals(leader)) leader = players.stream().findFirst().orElse(null);
        if (teleportOut) plugin.sessions().sendOut(p, def);
        plugin.lang().send(p, "left");
        broadcast("player-left", "player", p.getName());
    }

    /** Acorta la cuenta atrás (comando /boss start del líder). */
    public void forceCountdown(int seconds) {
        if (state == State.WAITING) {
            state = State.COUNTDOWN;
            counter = seconds;
            prepare();
            broadcast("countdown-start", "s", seconds);
        } else if (state == State.COUNTDOWN) {
            counter = Math.min(counter, seconds);
        }
    }

    public void addDamage(UUID id, double dmg) {
        if (state != State.FIGHTING || !players.contains(id)) return;
        damage.merge(id, dmg, Double::sum);
    }

    public void onPlayerDeath(Player p) {
        UUID id = p.getUniqueId();
        int d = deaths.merge(id, 1, Integer::sum);
        if (def.maxDeaths <= 0) return;
        if (d >= def.maxDeaths) {
            players.remove(id);
            plugin.sessions().unregister(id);
            plugin.sessions().markExit(id, def);
            plugin.lang().send(p, "eliminated");
            broadcast("player-eliminated", "player", p.getName());
        } else {
            plugin.lang().send(p, "death-left", "left", def.maxDeaths - d);
        }
    }

    // ------------------------------------------------------------------ ciclo de vida

    private void tick() {
        switch (state) {
            case WAITING -> tickWaiting();
            case COUNTDOWN -> tickCountdown();
            case INTRO -> {
                if (--counter <= 0) spawnBoss();
            }
            case FIGHTING -> tickFight();
            default -> { }
        }
    }

    private void tickWaiting() {
        if (players.isEmpty()) {
            cancelQuiet();
            return;
        }
        if (players.size() >= def.min) {
            state = State.COUNTDOWN;
            counter = def.countdown;
            prepare();
            broadcast("countdown-start", "s", counter);
        }
    }

    private void tickCountdown() {
        if (prepFailed) {
            abort("prep-failed");
            return;
        }
        if (kind == Kind.MANUAL) {
            if (players.isEmpty()) {
                cancelQuiet();
                return;
            }
            if (players.size() < def.min) {
                state = State.WAITING;
                broadcast("countdown-cancel");
                return;
            }
        }
        if (counter > 0) {
            counter--;
            if (counter > 0) {
                if (counter <= 5 || counter == 10 || counter == 30 || counter % 60 == 0) {
                    actionbar("countdown-tick", "s", counter);
                }
                return;
            }
        }
        // la cuenta llegó a 0
        if (players.size() < def.min) {
            abort("not-enough");
            return;
        }
        if (arena == null) { // la instancia aún se está copiando
            if (++waited > 30) abort("prep-failed");
            return;
        }
        beginIntro();
    }

    private void beginIntro() {
        if (def.arenaSpawn == null || def.bossSpawn == null) {
            abort("not-configured");
            return;
        }
        state = State.INTRO;
        counter = Math.max(1, def.intro);
        Location spawn = def.arenaSpawn.at(arena);
        Title title = Title.title(Lang.c(def.display), plugin.lang().comp("intro-sub"),
                Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(2), Duration.ofMillis(500)));
        for (UUID id : new ArrayList<>(players)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) {
                players.remove(id);
                plugin.sessions().unregister(id);
                continue;
            }
            p.teleport(spawn);
            p.showTitle(title);
        }
        if (players.isEmpty()) abort("not-enough");
    }

    private void spawnBoss() {
        Location loc = def.bossSpawn.at(arena);
        int level = def.scaleLevel ? Math.max(1, Math.min(def.maxLevel, players.size())) : 1;
        UUID id = plugin.spawnMythic(def.mythicMob, loc, level);
        if (id == null) {
            abort("spawn-failed");
            return;
        }
        bossUuid = id;
        plugin.sessions().registerBoss(id, this);
        state = State.FIGHTING;
        counter = def.timeLimit;
        broadcast("fight-start", "time", Lang.time(def.timeLimit));
    }

    private void tickFight() {
        if (players.isEmpty()) {
            defeat("all-dead");
            return;
        }
        Entity e = bossUuid == null ? null : Bukkit.getEntity(bossUuid);
        if (e == null || !e.isValid()) {
            if (++missingBoss > 5) {
                abort("boss-lost");
                return;
            }
        } else {
            missingBoss = 0;
        }
        if (--counter <= 0) {
            defeat("timeout");
            return;
        }
        actionbar("actionbar", "time", Lang.time(counter), "alive", players.size());
    }

    // ------------------------------------------------------------------ finales

    private void endState() {
        state = State.ENDED;
        if (task != null) task.cancel();
        if (bossUuid != null) plugin.sessions().unregisterBoss(bossUuid);
    }

    private void finish(long ticks) {
        Bukkit.getScheduler().runTaskLater(plugin, this::teardown, ticks);
    }

    /** Sala vacía antes de empezar: se cierra sin avisos. */
    private void cancelQuiet() {
        endState();
        teardown();
    }

    public void abort(String reasonKey) {
        if (state == State.ENDED) return;
        endState();
        broadcast("abort-" + reasonKey);
        finish(20L);
    }

    public void defeat(String reasonKey) {
        if (state == State.ENDED) return;
        endState();
        broadcast("defeat-" + reasonKey);
        finish(plugin.getConfig().getInt("end-delay-seconds", 10) * 20L);
    }

    /** Detención inmediata (admin o apagado del servidor). */
    public void forceStop() {
        if (state != State.ENDED) endState();
        broadcast("forced-stop");
        teardown();
    }

    public void victory(Player killer) {
        if (state == State.ENDED) return;
        endState();
        Lang l = plugin.lang();
        double total = damage.values().stream().mapToDouble(Double::doubleValue).sum();
        List<Map.Entry<UUID, Double>> ranking = new ArrayList<>(damage.entrySet());
        ranking.sort(Map.Entry.<UUID, Double>comparingByValue().reversed());

        List<String> lines = new ArrayList<>();
        Set<UUID> rewarded = new HashSet<>();
        Map<UUID, Integer> rankOf = new HashMap<>();
        int rank = 0;
        for (Map.Entry<UUID, Double> en : ranking) {
            rank++;
            UUID id = en.getKey();
            rankOf.put(id, rank);
            String name = names.getOrDefault(id, "?");
            double share = total <= 0 ? 0 : en.getValue() / total * 100.0;
            if (lines.size() < 5) {
                lines.add(l.raw("rank-line", "rank", rank, "player", name,
                        "damage", String.format(Locale.ROOT, "%.0f", en.getValue()),
                        "share", String.format(Locale.ROOT, "%.1f", share)));
            }
            if (share < def.minDamagePercent) continue;
            rewarded.add(id);
            runCommands(def.participation, name, rank, en.getValue());
            for (BossDefinition.Tier t : def.tiers) {
                if (rank >= t.from() && rank <= t.to()) runCommands(t.commands(), name, rank, en.getValue());
            }
            plugin.data().setCooldown("player:" + id + ":" + def.id, def.playerCooldown);
        }
        if (killer != null && damage.containsKey(killer.getUniqueId())) {
            UUID kid = killer.getUniqueId();
            runCommands(def.lastHit, killer.getName(), rankOf.getOrDefault(kid, 0), damage.get(kid));
        }
        if (def.type == BossDefinition.Type.FIXED) {
            plugin.data().setCooldown("arena:" + def.id, def.arenaCooldown);
        }

        Set<UUID> recipients = new LinkedHashSet<>(players);
        recipients.addAll(rewarded);
        for (UUID id : recipients) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            p.sendMessage(l.compP("victory-header", "boss", def.display));
            for (String line : lines) p.sendMessage(Lang.c(line));
            if (rewarded.contains(id)) l.send(p, "reward-given", "rank", rankOf.get(id));
            else l.send(p, "reward-none");
        }
        if (kind == Kind.EVENT && !ranking.isEmpty()) {
            String mvp = names.getOrDefault(ranking.get(0).getKey(), "?");
            Bukkit.broadcast(l.compP("victory-global", "boss", def.display, "n", names.size(), "mvp", mvp));
        }
        finish(plugin.getConfig().getInt("end-delay-seconds", 10) * 20L);
    }

    private void runCommands(List<String> cmds, String player, int rank, double dmg) {
        for (String raw : cmds) {
            String c = raw.replace("%player%", player)
                    .replace("%rank%", String.valueOf(rank))
                    .replace("%damage%", String.format(Locale.ROOT, "%.0f", dmg))
                    .replace("%boss%", def.id);
            if (c.startsWith("/")) c = c.substring(1);
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), c);
        }
    }

    /** Saca a todos, borra al boss, libera la arena y destruye la instancia. */
    public void teardown() {
        for (UUID id : new ArrayList<>(players)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) plugin.sessions().sendOut(p, def);
            plugin.sessions().unregister(id);
        }
        players.clear();
        if (bossUuid != null) {
            Entity e = Bukkit.getEntity(bossUuid);
            if (e != null) e.remove();
        }
        plugin.sessions().remove(this);
        if (instanceWorld && arena != null) plugin.instances().destroy(arena);
    }
}
