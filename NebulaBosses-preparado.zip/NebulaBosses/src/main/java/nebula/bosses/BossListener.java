package nebula.bosses;

import io.lumine.mythic.bukkit.events.MythicMobDeathEvent;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.util.List;
import java.util.Locale;

public final class BossListener implements Listener {
    private final NebulaBosses plugin;

    public BossListener(NebulaBosses plugin) {
        this.plugin = plugin;
    }

    private Player attacker(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile proj && proj.getShooter() instanceof Player shooter) return shooter;
        return null;
    }

    /** Suma el daño que cada jugador le hace al boss (para el ranking). */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        Session s = plugin.sessions().sessionOfBoss(e.getEntity().getUniqueId());
        if (s == null) return;
        Player p = attacker(e.getDamager());
        if (p == null) return;
        double dmg = e.getFinalDamage();
        if (e.getEntity() instanceof LivingEntity le) dmg = Math.min(dmg, le.getHealth());
        s.addDamage(p.getUniqueId(), dmg);
    }

    /** El boss murió: victoria. */
    @EventHandler
    public void onMythicDeath(MythicMobDeathEvent e) {
        Session s = plugin.sessions().sessionOfBoss(e.getEntity().getUniqueId());
        if (s == null) return;
        Player killer = e.getKiller() instanceof Player p ? p : null;
        s.victory(killer);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        Session s = plugin.sessions().sessionOf(p.getUniqueId());
        if (s == null || (s.state != Session.State.FIGHTING && s.state != Session.State.INTRO)) return;
        if (s.def.keepInventory) {
            e.setKeepInventory(true);
            e.setKeepLevel(true);
            e.getDrops().clear();
            e.setDroppedExp(0);
        }
        e.deathMessage(null);
        s.onPlayerDeath(p);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        BossDefinition out = plugin.sessions().consumeExit(p.getUniqueId());
        if (out != null) {
            e.setRespawnLocation(plugin.sessions().exitOf(out));
            return;
        }
        Session s = plugin.sessions().sessionOf(p.getUniqueId());
        if (s != null && s.arena != null && s.def.arenaSpawn != null
                && (s.state == Session.State.FIGHTING || s.state == Session.State.INTRO)) {
            Location l = s.def.arenaSpawn.at(s.arena);
            e.setRespawnLocation(l);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        Session s = plugin.sessions().sessionOf(p.getUniqueId());
        if (s != null) s.leave(p, true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        Session s = plugin.sessions().sessionOf(p.getUniqueId());
        if (s == null || p.hasPermission("nebulabosses.bypass")) return;
        if (s.state != Session.State.FIGHTING && s.state != Session.State.INTRO) return;
        String msg = e.getMessage();
        String cmd = msg.length() > 1 ? msg.substring(1).split(" ")[0].toLowerCase(Locale.ROOT) : "";
        int colon = cmd.indexOf(':');
        if (colon >= 0) cmd = cmd.substring(colon + 1);
        if (cmd.equals("boss") || cmd.equals("bosses") || cmd.equals("jefe")) return;
        List<String> blocked = plugin.getConfig().getStringList("blocked-commands");
        if (blocked.contains(cmd)) {
            e.setCancelled(true);
            plugin.lang().send(p, "blocked-command");
        }
    }
}
