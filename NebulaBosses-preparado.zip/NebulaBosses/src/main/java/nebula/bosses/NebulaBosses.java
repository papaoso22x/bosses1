package nebula.bosses;

import io.lumine.mythic.bukkit.MythicBukkit;
import org.bukkit.Location;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.time.ZoneId;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.regex.Pattern;

public final class NebulaBosses extends JavaPlugin {
    private static final Pattern ID = Pattern.compile("[a-z0-9_-]+");

    private Lang lang;
    private DataStore data;
    private InstanceWorlds instances;
    private SessionManager sessions;
    private ScheduleTask schedule;
    private final Map<String, BossDefinition> bosses = new LinkedHashMap<>();
    private File bossesFile;
    private YamlConfiguration bossesCfg;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new File(getDataFolder(), "bosses.yml").exists()) saveResource("bosses.yml", false);
        lang = new Lang(this);
        data = new DataStore(this);
        instances = new InstanceWorlds(this);
        sessions = new SessionManager(this);
        loadBosses();

        BossCommand cmd = new BossCommand(this);
        PluginCommand pc = getCommand("boss");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }
        getServer().getPluginManager().registerEvents(new BossListener(this), this);

        schedule = new ScheduleTask(this);
        schedule.runTaskTimer(this, 40L, 20L);
        instances.cleanupOrphans();
        getLogger().info("NebulaBosses activo con " + bosses.size() + " boss(es).");
    }

    @Override
    public void onDisable() {
        if (sessions != null) sessions.stopAll();
    }

    // ------------------------------------------------------------------ accesos

    public Lang lang() { return lang; }
    public DataStore data() { return data; }
    public InstanceWorlds instances() { return instances; }
    public SessionManager sessions() { return sessions; }
    public ScheduleTask schedule() { return schedule; }
    public Collection<BossDefinition> bosses() { return bosses.values(); }
    public YamlConfiguration bossesConfig() { return bossesCfg; }

    public BossDefinition boss(String id) {
        return id == null ? null : bosses.get(id.toLowerCase(Locale.ROOT));
    }

    public ZoneId zone() {
        String z = getConfig().getString("timezone", "system");
        try {
            return z.equalsIgnoreCase("system") ? ZoneId.systemDefault() : ZoneId.of(z);
        } catch (Exception e) {
            getLogger().warning("Zona horaria inválida '" + z + "', usando la del servidor.");
            return ZoneId.systemDefault();
        }
    }

    // ------------------------------------------------------------------ configuración

    public void reloadAll() {
        reloadConfig();
        lang.reload();
        loadBosses();
    }

    private void loadBosses() {
        bossesFile = new File(getDataFolder(), "bosses.yml");
        bossesCfg = YamlConfiguration.loadConfiguration(bossesFile);
        bosses.clear();
        ConfigurationSection root = bossesCfg.getConfigurationSection("bosses");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            String key = id.toLowerCase(Locale.ROOT);
            try {
                bosses.put(key, BossDefinition.load(key, root.getConfigurationSection(id)));
            } catch (Exception e) {
                getLogger().warning("Boss '" + id + "' inválido en bosses.yml: " + e.getMessage());
            }
        }
    }

    private void saveBosses() {
        try {
            bossesCfg.save(bossesFile);
        } catch (IOException e) {
            getLogger().log(Level.SEVERE, "No se pudo guardar bosses.yml", e);
        }
    }

    public static boolean validId(String id) {
        return ID.matcher(id).matches();
    }

    /** Crea un boss nuevo con valores por defecto. */
    public void createBoss(String id, BossDefinition.Type type) {
        ConfigurationSection root = bossesCfg.getConfigurationSection("bosses");
        if (root == null) root = bossesCfg.createSection("bosses");
        ConfigurationSection s = root.createSection(id);
        s.set("display-name", "&f" + id);
        s.set("mythic-mob", id);
        s.set("type", type.name());
        if (type == BossDefinition.Type.INSTANCE) s.set("template-world", "bosses_" + id);
        s.set("min-players", 1);
        s.set("max-players", 4);
        s.set("countdown-seconds", 30);
        s.set("intro-seconds", 5);
        s.set("time-limit-seconds", 600);
        s.set("max-deaths", 3);
        s.set("keep-inventory", true);
        s.set("scale-level", true);
        s.set("max-level", 4);
        s.set("modes.manual", true);
        s.set("modes.scheduled", false);
        s.set("cooldown.player-seconds", 3600);
        s.set("cooldown.arena-seconds", 600);
        s.set("rewards.min-damage-percent", 3);
        saveBosses();
        loadBosses();
    }

    /** key: lobby | arena-spawn | boss-spawn | exit */
    public void setLocation(String id, String key, Location l) {
        ConfigurationSection s = bossesCfg.getConfigurationSection("bosses." + id);
        if (s == null) return;
        ConfigurationSection locs = s.getConfigurationSection("locations");
        if (locs == null) locs = s.createSection("locations");
        BossDefinition.Pos.write(locs, key, l);
        saveBosses();
        loadBosses();
    }

    // ------------------------------------------------------------------ MythicMobs

    /** Invoca el mob con el nivel dado. Devuelve el UUID de la entidad o null si falló. */
    public UUID spawnMythic(String mobId, Location loc, int level) {
        try {
            Entity e = MythicBukkit.inst().getAPIHelper().spawnMythicMob(mobId, loc, level);
            return e == null ? null : e.getUniqueId();
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "No se pudo invocar el mob '" + mobId + "' de MythicMobs", e);
            return null;
        }
    }
}
