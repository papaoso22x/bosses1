package nebula.bosses;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

import java.util.ArrayList;
import java.util.List;

/** Configuración de un boss (una sección de bosses.yml). */
public final class BossDefinition {
    public enum Type { INSTANCE, FIXED }

    /** Ubicación guardada. En INSTANCE el mundo se ignora y se usa el de la copia. */
    public record Pos(String world, double x, double y, double z, float yaw, float pitch) {
        public static Pos read(ConfigurationSection s) {
            if (s == null) return null;
            return new Pos(s.getString("world", "world"), s.getDouble("x"), s.getDouble("y"), s.getDouble("z"),
                    (float) s.getDouble("yaw"), (float) s.getDouble("pitch"));
        }

        public static void write(ConfigurationSection parent, String key, Location l) {
            ConfigurationSection s = parent.createSection(key);
            s.set("world", l.getWorld().getName());
            s.set("x", l.getX());
            s.set("y", l.getY());
            s.set("z", l.getZ());
            s.set("yaw", (double) l.getYaw());
            s.set("pitch", (double) l.getPitch());
        }

        public Location at(World w) {
            return new Location(w, x, y, z, yaw, pitch);
        }

        /** Ubicación en su propio mundo (null si el mundo no está cargado). */
        public Location resolve() {
            World w = Bukkit.getWorld(world);
            return w == null ? null : at(w);
        }
    }

    public record Tier(int from, int to, List<String> commands) {}

    public final String id;
    public String display;
    public String mythicMob;
    public Type type = Type.FIXED;
    public String template = "";
    public int min = 1, max = 4, countdown = 30, intro = 5, timeLimit = 600, maxDeaths = 3, maxLevel = 4;
    public boolean keepInventory = true, scaleLevel = true;
    public boolean manual = true, scheduled = false;
    public long playerCooldown = 3600, arenaCooldown = 600;
    public Pos lobby, arenaSpawn, bossSpawn, exit;
    public final List<String> times = new ArrayList<>();
    public List<Integer> announce = new ArrayList<>(List.of(10, 5, 1));
    public int joinWindow = 180, eventMax = 12;
    public double minDamagePercent = 3.0;
    public final List<String> participation = new ArrayList<>();
    public final List<Tier> tiers = new ArrayList<>();
    public final List<String> lastHit = new ArrayList<>();

    private BossDefinition(String id) {
        this.id = id;
    }

    public boolean isReady() {
        if (arenaSpawn == null || bossSpawn == null) return false;
        if (type == Type.INSTANCE) return !template.isBlank();
        return arenaSpawn.resolve() != null;
    }

    public static BossDefinition load(String id, ConfigurationSection s) {
        BossDefinition d = new BossDefinition(id);
        d.display = s.getString("display-name", "&f" + id);
        d.mythicMob = s.getString("mythic-mob", id);
        d.type = Type.valueOf(s.getString("type", "FIXED").toUpperCase());
        d.template = s.getString("template-world", "");
        d.min = Math.max(1, s.getInt("min-players", 1));
        d.max = Math.max(d.min, s.getInt("max-players", 4));
        d.countdown = Math.max(1, s.getInt("countdown-seconds", 30));
        d.intro = Math.max(0, s.getInt("intro-seconds", 5));
        d.timeLimit = Math.max(30, s.getInt("time-limit-seconds", 600));
        d.maxDeaths = Math.max(0, s.getInt("max-deaths", 3));
        d.keepInventory = s.getBoolean("keep-inventory", true);
        d.scaleLevel = s.getBoolean("scale-level", true);
        d.maxLevel = Math.max(1, s.getInt("max-level", 4));

        ConfigurationSection modes = s.getConfigurationSection("modes");
        d.manual = modes == null || modes.getBoolean("manual", true);
        d.scheduled = modes != null && modes.getBoolean("scheduled", false);

        ConfigurationSection cd = s.getConfigurationSection("cooldown");
        if (cd != null) {
            d.playerCooldown = cd.getLong("player-seconds", 3600);
            d.arenaCooldown = cd.getLong("arena-seconds", 600);
        }

        ConfigurationSection loc = s.getConfigurationSection("locations");
        if (loc != null) {
            d.lobby = Pos.read(loc.getConfigurationSection("lobby"));
            d.arenaSpawn = Pos.read(loc.getConfigurationSection("arena-spawn"));
            d.bossSpawn = Pos.read(loc.getConfigurationSection("boss-spawn"));
            d.exit = Pos.read(loc.getConfigurationSection("exit"));
        }

        ConfigurationSection sc = s.getConfigurationSection("schedule");
        if (sc != null) {
            d.times.addAll(sc.getStringList("times"));
            List<Integer> a = sc.getIntegerList("announce-minutes");
            if (!a.isEmpty()) d.announce = a;
            d.joinWindow = Math.max(10, sc.getInt("join-window-seconds", 180));
            d.eventMax = Math.max(d.min, sc.getInt("max-players", 12));
        } else {
            d.eventMax = d.max;
        }

        ConfigurationSection r = s.getConfigurationSection("rewards");
        if (r != null) {
            d.minDamagePercent = r.getDouble("min-damage-percent", 3.0);
            d.participation.addAll(r.getStringList("participation"));
            d.lastHit.addAll(r.getStringList("last-hit"));
            ConfigurationSection top = r.getConfigurationSection("top");
            if (top != null) {
                for (String k : top.getKeys(false)) {
                    try {
                        int a, b;
                        if (k.contains("-")) {
                            String[] p = k.split("-");
                            a = Integer.parseInt(p[0].trim());
                            b = Integer.parseInt(p[1].trim());
                        } else {
                            a = b = Integer.parseInt(k.trim());
                        }
                        d.tiers.add(new Tier(a, b, top.getStringList(k)));
                    } catch (NumberFormatException ignored) {
                        // clave de puesto inválida: se ignora
                    }
                }
            }
        }
        return d;
    }
}
