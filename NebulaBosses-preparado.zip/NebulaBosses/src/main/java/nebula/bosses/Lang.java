package nebula.bosses;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.List;

/** Mensajes configurables (messages.yml) con colores &. */
public final class Lang {
    private static final LegacyComponentSerializer SER =
            LegacyComponentSerializer.builder().character('&').hexColors().build();

    private final NebulaBosses plugin;
    private YamlConfiguration cfg;

    public Lang(NebulaBosses plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File f = new File(plugin.getDataFolder(), "messages.yml");
        if (!f.exists()) plugin.saveResource("messages.yml", false);
        cfg = YamlConfiguration.loadConfiguration(f);
    }

    public static Component c(String s) {
        return SER.deserialize(s);
    }

    /** Texto sin prefijo, con las variables {clave} reemplazadas (kv = clave, valor, clave, valor...). */
    public String raw(String key, Object... kv) {
        String s = cfg.getString(key);
        if (s == null) s = "&c[mensaje faltante: " + key + "]";
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("{" + kv[i] + "}", String.valueOf(kv[i + 1]));
        }
        return s;
    }

    public Component comp(String key, Object... kv) {
        return c(raw(key, kv));
    }

    /** Componente con prefijo (para broadcasts y mensajes clicables). */
    public Component compP(String key, Object... kv) {
        return c(cfg.getString("prefix", "") + raw(key, kv));
    }

    public void send(CommandSender to, String key, Object... kv) {
        to.sendMessage(compP(key, kv));
    }

    public List<String> list(String key) {
        return cfg.getStringList(key);
    }

    /** 3725 -> "1h 2m" · 125 -> "2m 5s" · 40 -> "40s" */
    public static String time(long s) {
        if (s < 0) s = 0;
        long d = s / 86400, h = (s % 86400) / 3600, m = (s % 3600) / 60, x = s % 60;
        StringBuilder b = new StringBuilder();
        if (d > 0) b.append(d).append("d ");
        if (h > 0) b.append(h).append("h ");
        if (m > 0) b.append(m).append("m ");
        if (d == 0 && h == 0 && (x > 0 || b.length() == 0)) b.append(x).append("s");
        return b.toString().trim();
    }
}
