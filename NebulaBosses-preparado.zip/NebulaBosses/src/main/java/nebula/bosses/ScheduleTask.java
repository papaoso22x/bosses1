package nebula.bosses;

import org.bukkit.scheduler.BukkitRunnable;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Revisa cada segundo si toca avisar o abrir un evento programado. */
public final class ScheduleTask extends BukkitRunnable {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("H:mm");

    private final NebulaBosses plugin;
    private final Set<String> fired = new HashSet<>();

    public ScheduleTask(NebulaBosses plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        ZonedDateTime now = ZonedDateTime.now(plugin.zone());
        for (BossDefinition d : plugin.bosses()) {
            if (!d.scheduled) continue;
            for (String t : d.times) {
                ZonedDateTime c = next(t, now);
                if (c == null) continue;
                long delta = Duration.between(now, c).getSeconds();
                String key = d.id + "|" + c.toEpochSecond();
                if (delta <= 0) {
                    if (fired.add(key + "|start")) plugin.sessions().startEvent(d);
                } else {
                    for (int m : d.announce) {
                        if (delta <= m * 60L && delta > m * 60L - 10 && fired.add(key + "|" + m)) {
                            plugin.sessions().announceUpcoming(d, m);
                        }
                    }
                }
            }
        }
        if (fired.size() > 500) fired.clear();
    }

    /** Próxima ocurrencia de "DÍA HH:mm" (hasta 10 s en el pasado, para no perder el disparo). */
    public static ZonedDateTime next(String spec, ZonedDateTime now) {
        String[] p = spec.trim().split("\\s+");
        if (p.length != 2) return null;
        LocalTime time;
        try {
            time = LocalTime.parse(p[1], FMT);
        } catch (Exception e) {
            return null;
        }
        String day = p[0].toUpperCase(Locale.ROOT);
        boolean daily = day.equals("ALL") || day.equals("DIARIO") || day.equals("DAILY");
        DayOfWeek dow = daily ? null : parseDay(day);
        if (!daily && dow == null) return null;

        ZonedDateTime c = daily ? now.with(time) : now.with(TemporalAdjusters.nextOrSame(dow)).with(time);
        if (c.isBefore(now.minusSeconds(10))) c = c.plusDays(daily ? 1 : 7);
        return c;
    }

    private static DayOfWeek parseDay(String s) {
        return switch (s) {
            case "MON", "LUN" -> DayOfWeek.MONDAY;
            case "TUE", "MAR" -> DayOfWeek.TUESDAY;
            case "WED", "MIE" -> DayOfWeek.WEDNESDAY;
            case "THU", "JUE" -> DayOfWeek.THURSDAY;
            case "FRI", "VIE" -> DayOfWeek.FRIDAY;
            case "SAT", "SAB" -> DayOfWeek.SATURDAY;
            case "SUN", "DOM" -> DayOfWeek.SUNDAY;
            default -> null;
        };
    }

    /** Texto tipo "SAT 20:00 (en 2d 3h)" del próximo evento, o "-". */
    public String describeNext(BossDefinition d) {
        ZonedDateTime now = ZonedDateTime.now(plugin.zone());
        ZonedDateTime best = null;
        String spec = null;
        for (String t : d.times) {
            ZonedDateTime c = next(t, now);
            if (c != null && (best == null || c.isBefore(best))) {
                best = c;
                spec = t;
            }
        }
        if (best == null) return "-";
        return spec + " (en " + Lang.time(Math.max(0, Duration.between(now, best).getSeconds())) + ")";
    }
}
